﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using static exam_210419.Models.Author;

namespace exam_210419.Models
{
    public partial class Author
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("genre")]
        public string Genre { get; set; }

        internal static class Converter
        {
            public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
            {
                MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
                DateParseHandling = DateParseHandling.None,
                Converters =
            {
                new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
            },
            };
        }
    }

    public partial class Author
    {
        public static Author FromJson(string json) => JsonConvert.DeserializeObject<Author>(json, Converter.Settings);
    }


    public static class Serialize
    {
        public static string ToJson(this Author self) => JsonConvert.SerializeObject(self, Converter.Settings);
    }

}
