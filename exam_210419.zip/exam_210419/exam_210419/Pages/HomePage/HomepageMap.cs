﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace exam_210419.Pages.HomePage
{
    public partial class Homepage
    {
        public IWebElement Droppable => Wait
            .Until(d => { return d.FindElement(By.XPath("/html/body/div[1]/div[2]/div/div[1]/aside[1]/ul/li[4]/a")); });
    }
}
