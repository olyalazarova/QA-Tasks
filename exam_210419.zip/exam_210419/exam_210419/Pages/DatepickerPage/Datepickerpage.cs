﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace exam_210419.Pages.DatepickerPage
{
    public partial class Datepickerpage : BasePage
    {
        private readonly IWebDriver _driver;
        private readonly string _url = @"https://demoqa.com/datepicker/";

        public Datepickerpage(IWebDriver driver)
        {
            _driver = driver;

        }

        public WebDriverWait Wait => new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
        public void Navigate() => _driver.Navigate().GoToUrl(_url);
    }
}
