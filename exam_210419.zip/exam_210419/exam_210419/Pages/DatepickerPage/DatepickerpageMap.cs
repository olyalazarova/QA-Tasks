﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace exam_210419.Pages.DatepickerPage
{
    public partial class Datepickerpage
    {
        public IWebElement Datepicker => Wait
          .Until(d => { return d.FindElement(By.Id("datepicker")); });
    }
}
