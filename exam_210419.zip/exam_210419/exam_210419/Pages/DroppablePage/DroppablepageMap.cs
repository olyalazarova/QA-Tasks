﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace exam_210419.Pages.DroppablePage
{
    public partial class Droppablepage
    {
        public IWebElement DroppableElement => Wait
          .Until(d => { return d.FindElement(By.CssSelector("#draggable")); });

        public IWebElement TargetElement => Wait
          .Until(d => { return d.FindElement(By.CssSelector("#droppable")); });
    }
}
